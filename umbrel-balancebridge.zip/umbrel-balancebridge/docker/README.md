# Docker

Docker configuration files for containerizing the BalanceBridge Umbrel app.

This module will contain:
- Dockerfile(s)
- docker-compose.yml
- Build scripts
- Container configuration

