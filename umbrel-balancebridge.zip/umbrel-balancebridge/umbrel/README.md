# Umbrel Configuration

Umbrel-specific configuration and metadata.

This module will contain:
- app.json (Umbrel app manifest)
- Icon and branding assets
- Umbrel API integration
- App store metadata

