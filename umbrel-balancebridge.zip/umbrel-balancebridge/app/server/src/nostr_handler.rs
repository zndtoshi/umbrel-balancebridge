//! Nostr event handler for Bitcoin lookup requests
//!
//! Listens for encrypted events from the paired Android app,
//! processes Bitcoin lookup requests, and sends responses.

use anyhow::{Context, Result};
use nostr_sdk::prelude::*;
use std::time::{SystemTime, UNIX_EPOCH, Instant};
use std::panic::{catch_unwind, AssertUnwindSafe};
use tokio::time::{timeout, Duration};
use tokio::task::spawn_blocking;
use std::sync::Arc;
use tracing::{error, info, warn};

use crate::electrs::ElectrsClient;
use crate::pairing::PairingManager;
use crate::protocol::BitcoinLookupResponse;
use crate::xpub::{derive_addresses, is_bitcoin_address, is_xpub};

// BalanceBridge event kind (must match Android app)
// We use the SAME kind in both directions and distinguish by author pubkey.
pub const BALANCEBRIDGE_REQUEST_KIND: u16 = 30078;
pub const BALANCEBRIDGE_RESPONSE_KIND: u16 = 30079;

impl NostrHandler {
    /// Extract request ID from event tags, or generate one deterministically
    fn extract_request_id(event: &Event) -> String {
        // Look for ["req", "<request_id>"] tag
        for tag in event.tags.iter() {
            if tag.kind() == TagKind::Custom("req".into()) {
                if let Some(value) = tag.as_slice().get(1) {
                    return value.to_string();
                }
            }
        }

        // Fallback: generate deterministic ID from event ID
        format!("req_{}", &event.id.to_hex()[0..16])
    }

    /// Check if event is a valid BalanceBridge request for this server
    fn is_balancebridge_request(event: &Event, server_pubkey: &PublicKey) -> Option<String> {
        let mut req_id: Option<String> = None;
        let mut p_match = false;

        for tag in event.tags.iter() {
            let tag_vec = tag.clone().to_vec();

            if tag_vec.len() < 2 {
                continue;
            }

            match tag_vec[0].as_str() {
                "req" => {
                    req_id = Some(tag_vec[1].clone());
                }
                "p" => {
                    if tag_vec[1] == server_pubkey.to_hex() {
                        p_match = true;
                    }
                }
                _ => {}
            }
        }

        if p_match {
            req_id
        } else {
            None
        }
    }
}

/// Handles Nostr communication with Android app
pub struct NostrHandler {
    client: Client,
    keys: Keys,
    pairing_manager: PairingManager,
    electrs_client: Arc<ElectrsClient>,
}

impl NostrHandler {
    /// Create a new Nostr handler
    pub async fn new(
        keys: Keys,
        pairing_manager: PairingManager,
        relay_urls: Vec<String>,
        electrs_client: Arc<ElectrsClient>,
    ) -> Result<Self> {
        let client = Client::new(keys.clone());

        // Add all relays (continue on failure for redundancy)
        let mut added_count = 0;
        for relay_url in &relay_urls {
            match Url::parse(relay_url) {
                Ok(url) => {
                    match client.add_relay(url).await {
                        Ok(_) => {
                            info!("Relay connected: {}", relay_url);
                            added_count += 1;
                        }
                        Err(e) => {
                            warn!("Relay failed: {} - {}", relay_url, e);
                        }
                    }
                }
                Err(e) => {
                    warn!("Invalid relay URL {}: {}", relay_url, e);
                }
            }
        }

        if added_count == 0 {
            return Err(anyhow::anyhow!("Failed to add any relays"));
        }

        // Connect to all relays and wait for completion
        client.connect().await;
        println!("=== CLIENT CONNECT() CALLED ===");
        info!("Nostr relays: {}", relay_urls.join(", "));
        info!("Connected to {} relay(s)", added_count);

        let handler = Self {
            client,
            keys,
            pairing_manager,
            electrs_client,
        };

        handler.subscribe_requests().await?;

        Ok(handler)
    }

    async fn subscribe_requests(&self) -> Result<()> {
        let ten_minutes_ago = Timestamp::now().as_secs().saturating_sub(600);

        // Broad debug subscription: any kind=30078 from last 10 minutes
        let filter = Filter::new()
            .kinds(vec![Kind::Custom(BALANCEBRIDGE_REQUEST_KIND)])
            .since(Timestamp::from(ten_minutes_ago));

        println!("=== SUBSCRIBE_REQUESTS CALLED ===");
        println!("=== SUBSCRIBING kind={} since={} ===", BALANCEBRIDGE_REQUEST_KIND, ten_minutes_ago);

        self.client.subscribe(filter, None).await?;

        println!("=== SUBSCRIBE_REQUESTS DONE ===");
        Ok(())
    }

    /// Start listening for events from the paired Android app
    pub async fn start_listening(&self) -> Result<()> {
        println!("=== START_LISTENING ENTERED ===");

        // Get notification stream (subscription already active from startup)
        let mut notifications = self.client.notifications();

        // Get paired Android pubkey (if any)
        let android_pubkey = self.pairing_manager.get_android_pubkey()?;

        if let Some(ref pk) = android_pubkey {
            info!("Listening for events from Android pubkey: {}", pk.to_hex());
        } else {
            warn!("No Android app paired yet, accepting all kind 30078 events for pairing...");
        }

        // Process incoming events with reconnection handling
        loop {
            match notifications.recv().await {
                Ok(notification) => match notification {
                    RelayPoolNotification::Event { event, .. } => {
                        println!(
                            "=== NOTIF EVENT RECEIVED === kind={:?} pubkey={} id={} created_at={}",
                            event.kind,
                            event.pubkey.to_hex(),
                            event.id.to_hex(),
                            event.created_at.as_secs()
                        );
                        println!("=== TAGS === {:?}", event.tags);

                        if event.kind == Kind::Custom(BALANCEBRIDGE_REQUEST_KIND) {
                            if let Some(req_id) = Self::is_balancebridge_request(&event, &self.keys.public_key()) {
                                println!("=== VALID BALANCEBRIDGE REQUEST === req_id={}", req_id);
                                if let Err(e) = self.handle_event(*event).await {
                                    eprintln!("=== HANDLE_EVENT ERROR === {}", e);
                                }
                            } else {
                                // Ignore spam
                                println!("--- ignored kind=30078 (not a BalanceBridge request)");
                            }
                        }
                    }
                    RelayPoolNotification::Message { .. } => {
                        // Ignore other message types
                    }
                    RelayPoolNotification::Shutdown => {
                        warn!("Relay pool shutdown (will reconnect automatically)");
                    }
                },
                Err(e) => {
                    warn!("Error receiving notification: {}", e);
                    // Continue listening - do not exit loop
                }
            }
        }
    }

    /// Check if event is within expiration tolerance (60 seconds)
    /// Returns Ok(()) if valid, logs warning if expired but doesn't reject
    fn check_event_expiration(&self, event: &Event) -> Result<()> {
        let event_time = event.created_at.as_secs();
        let now = SystemTime::now()
            .duration_since(UNIX_EPOCH)
            .context("System time error")?
            .as_secs();
        
        let delta = if now > event_time {
            now - event_time
        } else {
            0
        };
        
        if delta > 60 {
            warn!(
                "Event is {} seconds old (max 60s), but processing anyway",
                delta
            );
        } else {
            info!(
                "Event timestamp check: created_at={}, now={}, delta={}s",
                event_time, now, delta
            );
        }

        Ok(())
    }


    /// Handle a pairing event ("hello / paired")
    async fn handle_pairing_event(&self, event: Event) -> Result<()> {
        // Try to decrypt the event
        let decrypted = match self.keys.nip44_decrypt(&event.pubkey, &event.content).await {
            Ok(msg) => msg,
            Err(e) => {
                warn!("Failed to decrypt pairing event: {}", e);
                return Ok(());
            }
        };

        if decrypted == "hello / paired" {
            info!("Received pairing from: {}", event.pubkey.to_hex());

            // Get relays from the event tags (if available)
            // For now, use default relays
            let relays = self.pairing_manager.get_relays()
                .unwrap_or_else(|_| vec!["wss://relay.damus.io".to_string()]);

            // Store the pairing
            self.pairing_manager.store_pairing(event.pubkey, relays)?;

            info!("Android app paired successfully");
        }

        Ok(())
    }

    /// Handle an incoming BalanceBridge request event
    async fn handle_event(&self, event: Event) -> Result<()> {
        // Extract req_id first for panic logging
        let mut req_id: Option<String> = None;
        for tag in event.tags.iter() {
            let parts = tag.clone().to_vec();
            if parts.len() >= 2 && parts[0] == "req" {
                req_id = Some(parts[1].clone());
            }
        }
        let req_id_outer = req_id.unwrap_or_else(|| "unknown".to_string());
        let req_id_inner = req_id_outer.clone();

        // Panic trap for this handler ONLY
        let fut = AssertUnwindSafe(async move {
            let t0 = Instant::now();
            log::info!(
                "BB TRACE A: handler entered req_id={} (+{:?})",
                req_id_inner,
                t0.elapsed()
            );

            info!("=== HANDLE_EVENT ENTERED ===");
            info!(
                "Incoming event id={} pubkey={} kind={:?}",
                event.id,
                event.pubkey,
                event.kind
            );

            // --- Extract req tag ---
            let mut req_id: Option<String> = None;

            for tag in event.tags.iter() {
                let parts = tag.clone().to_vec();
                if parts.len() >= 2 && parts[0] == "req" {
                    req_id = Some(parts[1].clone());
                }
            }

            let req_id = match req_id {
                Some(r) => r,
                None => {
                    warn!("No req tag found — aborting");
                    return Ok(());
                }
            };

            info!("=== BALANCEBRIDGE REQUEST ACCEPTED === req_id={}", req_id);
            info!(
                "=== STEP 1: WILL SEND RESPONSE === req_id={} client_pubkey={}",
                req_id,
                event.pubkey
            );
            info!("Event content: {}", event.content);

            log::info!("BB TRACE B: before parse/decrypt req_id={}", req_id);

            // --- Parse request JSON ---
            let parsed: serde_json::Value = match serde_json::from_str(&event.content) {
                Ok(v) => v,
                Err(e) => {
                    error!("JSON parse failed: {}", e);
                    return Ok(());
                }
            };

            let request_type = parsed
                .get("type")
                .and_then(|v| v.as_str())
                .unwrap_or("unknown");

            info!("Request type = {}", request_type);

            log::info!("BB TRACE C: after parse/decrypt req_id={} (+{:?})", req_id, t0.elapsed());

            // Extract query from request
            let query = parsed
                .get("query")
                .and_then(|v| v.as_str())
                .unwrap_or("");

            println!("=== BB TRACE D: BEFORE LOOKUP DISPATCH === req_id={}", req_id);

            println!(
                "=== BB TRACE E: LOOKUP START === req_id={} query={}",
                req_id,
                query
            );

            // Hard timeout around the whole lookup + response work
            let req_id_outer = req_id.clone();
            let query_outer = query.clone();

            let work = async {
                println!("=== BB TRACE F: ENTER WORK === req_id={}", req_id_outer);

                // Clone what we need into the blocking thread
                let req_id_for_block = req_id_outer.clone();
                let query_for_block = query_outer.to_string();

                // IMPORTANT: use the shared electrs client created at startup.
                // Your handler struct should already have an Arc<ElectrsClient>. Use it here.
                let electrs_for_block: Arc<crate::electrs::ElectrsClient> = Arc::clone(&self.electrs_client);

                println!("=== BB TRACE F3: SPAWN_BLOCKING LOOKUP === req_id={}", req_id_for_block);

                let join = spawn_blocking(move || -> Result<String, anyhow::Error> {
                    println!("=== BB TRACE F4: IN BLOCKING LOOKUP THREAD ===");

                    let (confirmed, unconfirmed) = electrs_for_block
                        .get_address_balance(&query_for_block)
                        .map_err(|e| anyhow::anyhow!("electrs balance error: {}", e))?;

                    let txids = electrs_for_block
                        .get_address_txs(&query_for_block)
                        .map_err(|e| anyhow::anyhow!("electrs tx error: {}", e))?;

                    let mut response = crate::protocol::BitcoinLookupResponse::new(query_for_block);
                    response.set_balance(confirmed, unconfirmed);
                    response.set_transactions(txids);

                    let json = response.to_json();

                    println!(
                        "=== BB TRACE F5: BLOCKING LOOKUP DONE === req_id={} bytes={}",
                        req_id_for_block,
                        json.len()
                    );

                    Ok(json)
                });

                // HARD timeout around the join handle (this timeout always works now)
                let response_json = match timeout(Duration::from_secs(20), join).await {
                    Ok(Ok(Ok(json))) => {
                        println!("=== BB TRACE F6: LOOKUP OK === req_id={}", req_id_outer);
                        json
                    }
                    Ok(Ok(Err(e))) => {
                        println!("=== BB TRACE FX: LOOKUP ERROR === req_id={} err={}", req_id_outer, e);
                        return Err(e);
                    }
                    Ok(Err(e)) => {
                        println!("=== BB TRACE FY: LOOKUP JOIN ERROR === req_id={} err={}", req_id_outer, e);
                        return Err(anyhow::anyhow!("lookup join error: {}", e));
                    }
                    Err(_) => {
                        println!("=== BB TRACE FT: LOOKUP TIMEOUT === req_id={}", req_id_outer);
                        return Err(anyhow::anyhow!("bitcoin lookup timed out"));
                    }
                };

                // ------------------------------
                // PUT YOUR EXISTING SUCCESS RESPONSE PUBLISH HERE
                // Keep the exact same encryption/tags (p + req) you already use.
                println!("=== BB TRACE J: RESPOND START === req_id={}", req_id_outer);

                // Build response event
                let mut builder = EventBuilder::new(
                    Kind::Custom(BALANCEBRIDGE_RESPONSE_KIND),
                    response_json,
                );

                // add tags explicitly (nostr-sdk ≥0.44 style)
                builder = builder
                    .tag(Tag::parse(vec![
                        "p".to_string(),
                        event.pubkey.to_string(),
                    ])?)
                    .tag(Tag::parse(vec![
                        "req".to_string(),
                        req_id_outer.clone(),
                    ])?);

                // sign event
                let response_event = builder
                    .sign_with_keys(&self.keys)?;

                // Publish response
                self.client.send_event(&response_event).await?;

                println!("=== BB TRACE K: RESPOND DONE === req_id={}", req_id_outer);

                Ok::<(), anyhow::Error>(())
            };

            match timeout(Duration::from_secs(20), work).await {
                Ok(Ok(())) => {
                    println!("=== BB TRACE Z: HANDLER DONE OK === req_id={}", req_id);
                }
                Ok(Err(e)) => {
                    println!("=== BB TRACE X: WORK ERROR === req_id={} err={}", req_id, e);

                    // GUARANTEED error response publish (must not hang)
                    let err_json = format!(
                        "{{\"type\":\"error\",\"req\":\"{}\",\"error\":\"{}\"}}",
                        req_id,
                        e.to_string().replace('"', "'")
                    );

                    println!("=== BB TRACE Y: RESPOND ERROR START === req_id={}", req_id);

                    let _ = self.publish_error_response(
                        req_id.clone(),
                        event.pubkey.clone(),
                        e.to_string(),
                    ).await;

                    println!("=== BB TRACE Y2: RESPOND ERROR DONE === req_id={}", req_id);
                }
                Err(_) => {
                    println!("=== BB TRACE T: TIMEOUT === req_id={}", req_id);

                    let err_json = format!(
                        "{{\"type\":\"error\",\"req\":\"{}\",\"error\":\"lookup_timeout\"}}",
                        req_id
                    );

                    println!("=== BB TRACE TY: RESPOND TIMEOUT ERROR START === req_id={}", req_id);

                    let _ = self.publish_error_response(
                        req_id.clone(),
                        event.pubkey.clone(),
                        "lookup_timeout".to_string(),
                    ).await;

                    println!("=== BB TRACE TY2: RESPOND TIMEOUT ERROR DONE === req_id={}", req_id);
                }
            }

            Ok::<(), anyhow::Error>(())
        });

        match catch_unwind(|| fut) {
            Ok(fut) => {
                if let Err(e) = fut.await {
                    log::error!(
                        "BB HANDLER ERROR req_id={} err={}",
                        req_id_outer,
                        e
                    );
                }
            }
            Err(_) => {
                log::error!(
                    "BB PANIC: handler panicked req_id={}",
                    req_id_outer
                );
            }
        }

        Ok(())
    }

    /// Process a Bitcoin lookup request with timeout and step logging
    async fn process_bitcoin_lookup(&self, query: &str) -> Result<BitcoinLookupResponse> {
        info!("LOOKUP STEP A: input query={}", query);

        // 15s hard timeout so requests never hang forever
        let result = timeout(Duration::from_secs(15), async {
            let mut response = BitcoinLookupResponse::new(query.to_string());

            if is_xpub(query) {
                // Handle xpub/ypub/zpub/tpub
                info!("LOOKUP STEP B: parsing xpub");
                let addresses = derive_addresses(query, 20)
                    .map_err(|e| anyhow::anyhow!("xpub derivation failed: {}", e))?;
                info!("LOOKUP STEP C: derived {} addresses from xpub (gap_limit=20)", addresses.len());

                let mut total_confirmed = 0u64;
                let mut total_unconfirmed = 0u64;
                let mut all_txids = Vec::new();

                for address in addresses {
                    match self.electrs_client.get_address_balance(&address).await {
                        Ok((confirmed, unconfirmed)) => {
                            total_confirmed += confirmed;
                            total_unconfirmed += unconfirmed;
                        }
                        Err(e) => {
                            warn!("Failed to get balance for derived address {}: {}", address, e);
                        }
                    }

                    match self.electrs_client.get_address_txs(&address).await {
                        Ok(txids) => {
                            all_txids.extend(txids);
                        }
                        Err(e) => {
                            warn!("Failed to get transactions for derived address {}: {}", address, e);
                        }
                    }
                }

                // Deduplicate txids
                all_txids.sort();
                all_txids.dedup();

                info!("LOOKUP STEP D: xpub query complete - confirmed={} sats, unconfirmed={} sats, tx_count={}",
                    total_confirmed, total_unconfirmed, all_txids.len());

                response.confirmed_balance = total_confirmed as i64;
                response.unconfirmed_balance = total_unconfirmed as i64;
                response.transactions = all_txids
                    .into_iter()
                    .map(|txid| crate::protocol::TransactionInfo {
                        txid,
                        timestamp: 0, // Electrum doesn't provide timestamps
                        amount: 0,    // Electrum doesn't provide amounts in history
                        confirmations: 1, // Assume confirmed if in history
                    })
                    .collect();
            } else if is_bitcoin_address(query) {
                // Handle single Bitcoin address
                info!("LOOKUP STEP B: parsing address");
                let addr = query; // Already validated by is_bitcoin_address

                info!("LOOKUP STEP C: querying electrs for balance");
                let (confirmed, unconfirmed) = self.electrs_client
                    .get_address_balance(addr)
                    .await
                    .map_err(|e| anyhow::anyhow!("electrs balance error: {}", e))?;

                info!("LOOKUP STEP D: querying electrs for transactions");
                let txids: Vec<String> = self.electrs_client
                    .get_address_txs(addr)
                    .await
                    .map_err(|e| anyhow::anyhow!("electrs tx error: {}", e))?;

                info!("LOOKUP STEP E: address query complete - confirmed={} sats, unconfirmed={} sats, tx_count={}",
                    confirmed, unconfirmed, txids.len());

                response.confirmed_balance = confirmed as i64;
                response.unconfirmed_balance = unconfirmed as i64;
                response.transactions = txids
                    .into_iter()
                    .map(|txid| crate::protocol::TransactionInfo {
                        txid,
                        timestamp: 0, // Electrum doesn't provide timestamps
                        amount: 0,    // Electrum doesn't provide amounts in history
                        confirmations: 1, // Assume confirmed if in history
                    })
                    .collect();
            } else {
                return Err(anyhow::anyhow!("Invalid query: not an address or xpub"));
            }

            Ok(response)
        }).await;

        match result {
            Ok(Ok(res)) => {
                info!("LOOKUP STEP F: success - confirmed={}, unconfirmed={}, tx_count={}",
                    res.confirmed_balance, res.unconfirmed_balance, res.transactions.len());
                Ok(res)
            }
            Ok(Err(e)) => {
                error!("LOOKUP FAILED inside task: {}", e);
                Err(e)
            }
            Err(_) => {
                error!("LOOKUP TIMEOUT after 15s");
                Err(anyhow::anyhow!("lookup timeout"))
            }
        }
    }

    /// Send a response back to the Android app
    async fn send_response(&self, recipient: PublicKey, response: &BitcoinLookupResponse, request_id: &str) -> Result<()> {
        let recipient_short = format!("{}...{}",
            &recipient.to_hex()[0..8],
            &recipient.to_hex()[recipient.to_hex().len()-8..]);

        let response_json = serde_json::to_string(response)
            .context("Failed to serialize response")?;

        info!("Sending BalanceBridge response to {} (req_id={}): confirmed={} sats, unconfirmed={} sats, tx_count={}",
            recipient_short, request_id, response.confirmed_balance, response.unconfirmed_balance, response.transactions.len());

        // Encrypt the response
        let encrypted = match self.keys.nip44_encrypt(&recipient, &response_json).await {
            Ok(enc) => enc,
            Err(e) => {
                error!("Failed to encrypt response to {}: {}", recipient_short, e);
                return Err(anyhow::anyhow!("Encryption failed: {}", e));
            }
        };

        // Create unsigned event with proper tags
        let unsigned = EventBuilder::new(Kind::Custom(BALANCEBRIDGE_RESPONSE_KIND), encrypted)
            .tags(vec![
                Tag::public_key(recipient),  // "p" tag with recipient pubkey
                Tag::parse(["req", request_id])?, // "req" tag
            ])
            .build(self.keys.public_key());

        // Sign the event
        let event = self.keys.sign_event(unsigned).await
            .context("Failed to sign event")?;

        match self.client.send_event(&event).await {
            Ok(_) => {
                info!("Published BalanceBridge response: req_id={}, client_pubkey={}", request_id, recipient_short);
                Ok(())
            }
            Err(e) => {
                error!("Failed to publish BalanceBridge response to {}: {}", recipient_short, e);
                Err(anyhow::anyhow!("Failed to send event: {}", e))
            }
        }
    }

    /// Publish an error response event
    async fn publish_error_response(
        &self,
        req_id: String,
        recipient_pubkey: PublicKey,
        message: String,
    ) -> Result<(), anyhow::Error> {
        let json = serde_json::json!({
            "type": "error",
            "req": req_id,
            "error": message
        });

        let mut builder = EventBuilder::new(
            Kind::Custom(BALANCEBRIDGE_RESPONSE_KIND),
            json.to_string(),
        );

        // add tags explicitly (nostr-sdk ≥0.44 style)
        builder = builder
            .tag(Tag::parse(vec![
                "p".to_string(),
                recipient_pubkey.to_string(),
            ])?)
            .tag(Tag::parse(vec![
                "req".to_string(),
                req_id.clone(),
            ])?);

        // sign event
        let response_event = builder
            .sign_with_keys(&self.keys)?;

        info!("ERROR RESPONSE BUILT req_id={} event_id={}", req_id, response_event.id.to_hex());

        // Publish response
        self.client.send_event(&response_event).await?;

        Ok(())
    }
}

