use anyhow::{Result, anyhow};
use electrum_client::{Client, ElectrumApi};
use electrum_client::bitcoin::{Address, ScriptBuf, Network};
use std::net::ToSocketAddrs;
use std::str::FromStr;
use std::time::Duration;
use tracing::info;

pub struct ElectrsClient {
    client: Client,
    addr: String,
}

impl ElectrsClient {
    /// NOTE: electrum_client::Client is blocking. This constructor is blocking.
    /// Always call it from startup (main) or from spawn_blocking, not inside hot async paths.
    pub fn new() -> Result<Self> {
        // IMPORTANT: inside a Docker container, 127.0.0.1 points to the container itself.
        // On Umbrel, electrs is exposed on the host. Default to docker bridge gateway.
        // You can override with ELECTRS_ADDR if needed (recommended).
        let addr = std::env::var("ELECTRS_ADDR")
            .unwrap_or_else(|_| "172.17.0.1:50001".to_string());

        info!("ElectrsClient using ELECTRS_ADDR={}", addr);

        // Preflight TCP connect with short timeout to avoid indefinite hangs
        preflight_tcp(&addr)?;

        let client = Client::new(&addr)
            .map_err(|e| anyhow!("Failed to create electrum_client::Client for {}: {}", addr, e))?;

        Ok(Self { client, addr })
    }

    pub fn test_connectivity(&self) -> Result<()> {
        // ping is blocking; ensure caller uses it at startup or spawn_blocking
        self.client
            .ping()
            .map_err(|e| anyhow!("Electrs ping failed ({}) : {}", self.addr, e))?;
        Ok(())
    }

    pub fn get_address_balance(&self, address: &str) -> Result<(u64, u64)> {
        let addr = Address::from_str(address)?
            .require_network(Network::Bitcoin)?;
        let script: ScriptBuf = addr.script_pubkey();

        let balance = self.client.script_get_balance(&script)?;
        let confirmed = balance.confirmed.max(0) as u64;
        let unconfirmed = balance.unconfirmed.max(0) as u64;

        Ok((confirmed, unconfirmed))
    }

    pub fn get_address_txs(&self, address: &str) -> Result<Vec<String>> {
        let addr = Address::from_str(address)?
            .require_network(Network::Bitcoin)?;
        let script: ScriptBuf = addr.script_pubkey();

        let history = self.client.script_get_history(&script)?;
        Ok(history
            .into_iter()
            .map(|h| h.tx_hash.to_string())
            .collect())
    }
}

fn preflight_tcp(addr: &str) -> Result<()> {
    // Try to connect quickly to avoid hanging forever in electrum_client internals
    let mut addrs = addr
        .to_socket_addrs()
        .map_err(|e| anyhow!("Invalid ELECTRS_ADDR '{}': {}", addr, e))?;

    let sock = addrs
        .next()
        .ok_or_else(|| anyhow!("ELECTRS_ADDR '{}' did not resolve to any socket address", addr))?;

    let stream = std::net::TcpStream::connect_timeout(&sock, Duration::from_secs(3))
        .map_err(|e| anyhow!("Electrs TCP preflight failed to {} ({}): {}", addr, sock, e))?;

    // best-effort: don't linger
    let _ = stream.set_read_timeout(Some(Duration::from_secs(3)));
    let _ = stream.set_write_timeout(Some(Duration::from_secs(3)));

    Ok(())
}

