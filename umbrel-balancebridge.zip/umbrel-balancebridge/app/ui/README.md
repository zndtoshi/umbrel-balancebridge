# UI

Web-based user interface for BalanceBridge Umbrel app.

This module will contain:
- Web frontend (HTML/CSS/JavaScript or framework)
- UI components for managing BalanceBridge
- Integration with server APIs
- Umbrel UI styling and components

